package com.dicoding.courseschedule.util

enum class SortType {

    TIME,

    COURSE_NAME,

    LECTURER

}