package com.dicoding.courseschedule.ui.home

import androidx.test.core.app.ActivityScenario
import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.action.ViewActions.click
import androidx.test.espresso.intent.Intents
import androidx.test.espresso.intent.Intents.intended
import androidx.test.espresso.intent.matcher.IntentMatchers.hasComponent
import androidx.test.espresso.matcher.ViewMatchers.withId
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.dicoding.courseschedule.R
import com.dicoding.courseschedule.ui.add.AddCourseActivity
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class UITest {

    @Before
    fun setup() {
        launchHomeActivity()
        initializeIntents()
    }

    @After
    fun teardown() {
        releaseIntents()
    }

    @Test
    fun testAddNewNavigation() {
        clickAddNewButton()
        verifyAddNewActivityDisplayed()
    }

    private fun launchHomeActivity() {
        ActivityScenario.launch(HomeActivity::class.java)
    }

    private fun initializeIntents() {
        Intents.init()
    }

    private fun releaseIntents() {
        Intents.release()
    }

    private fun clickAddNewButton() {
        onView(withId(R.id.action_add)).perform(click())
    }

    private fun verifyAddNewActivityDisplayed() {
        intended(hasComponent(AddCourseActivity::class.java.name))
    }
}